CREATE DATABASE yearly_waste;

CREATE TABLE yearly_waste.local_govt (
    local_govt_id int,
    local_govt_name varchar(255)
);

ALTER TABLE yearly_waste.local_govt
ADD PRIMARY KEY (local_govt_id);

CREATE TABLE yearly_waste.locality (
    locality_id int,
    locality_name varchar(255)
);

ALTER TABLE yearly_waste.locality
ADD PRIMARY KEY (locality_id);

CREATE TABLE yearly_waste.wrrg (
    wrrg_id int,
    wrrg_name varchar(255)
);

ALTER TABLE yearly_waste.wrrg
ADD PRIMARY KEY (wrrg_id);

CREATE TABLE yearly_waste.postcode (
    local_govt_id int,
    locality_id int,
    postcode_no int
);

ALTER TABLE yearly_waste.postcode
ADD CONSTRAINT PK_Postcode PRIMARY KEY (local_govt_id, locality_id);

GRANT FILE ON *.* TO wasteOnboarding@wasteinfo.mysql.database.azure.com;

load data local infile 'C:/Users/abelj/Documents/MS_DS/S5/5120/onboarding_TP17/database/upload_postcode.csv'
into table yearly_waste.postcode
fields terminated by ','
optionally enclosed by '"'
LINES TERMINATED BY '\r\n'
ignore 1 lines; -- skip the header row

CREATE TABLE yearly_waste.waste (
    local_govt_id int,
    waste_year year,
    wrrg_id int,
    waste_garbage float(2), 
    waste_recycle_collected float(2),
    waste_recycle_processed float(2),
    waste_organic_collected float(2),
    waste_organic_processed float(2),
    waste_total_collected float(2),
    waste_total_processed float(2)
);

ALTER TABLE yearly_waste.waste
ADD CONSTRAINT PK_Waste PRIMARY KEY (local_govt_id, waste_year);

load data local infile 'C:/Users/abelj/Documents/MS_DS/S5/5120/onboarding_TP17/database/upload_waste.csv'
into table yearly_waste.waste
fields terminated by ','
optionally enclosed by '"'
LINES TERMINATED BY '\r\n'
ignore 1 lines; -- skip the header row